function value = contains(text, pattern)
assert(ischar(text) && ischar(pattern));
value = ~isempty(strfind(text, pattern));
end
