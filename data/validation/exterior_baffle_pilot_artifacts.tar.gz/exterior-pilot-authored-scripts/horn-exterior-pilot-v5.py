from pathlib import Path
import json, shutil
import gmsh, meshio, numpy as np
out=Path('/tmp/horn-exterior-reference/results/exterior-pilot-v5');out.mkdir(parents=True,exist_ok=False)
step=Path('/tmp/horn-report-cutoffs/results/example-800-1600-v2/outputs/auto/refinement/refine_hyperbolic_0001.step')
shutil.copyfile(step,out/'horn-air.step')
length=.11790625; radius=.5; mouth=.08870898640584517
h_inner=.008;h_outer=.04
# The solid is a finite circular baffle/body with the horn's air cavity removed.
gmsh.initialize()
gmsh.model.add('finite-baffle-horn')
body=gmsh.model.occ.addCylinder(0,0,-.01,0,0,length+.01,radius)
air=gmsh.model.occ.importShapes(str(step))
solid,_=gmsh.model.occ.cut([(3,body)],air)
gmsh.model.occ.synchronize()
assert len(solid)==1
surfaces=gmsh.model.getBoundary(solid,oriented=False)
source=[];rigid=[];inner=[]
for _,tag in surfaces:
 b=gmsh.model.getBoundingBox(2,tag)
 if max(abs(b[2]),abs(b[5]))<1e-6:source.append(tag)
 else:rigid.append(tag)
 if b[2]>=-1e-6 and max(abs(b[0]),abs(b[1]),abs(b[3]),abs(b[4]))<mouth+1e-5:inner.append(tag)
assert len(source)==1
for tags,number,name in [(source,2,'source'),(rigid,4,'rigid')]:
 gmsh.model.addPhysicalGroup(2,tags,number);gmsh.model.setPhysicalName(2,number,name)
gmsh.model.mesh.setOutwardOrientation(solid[0][1])
distance=gmsh.model.mesh.field.add('Distance');gmsh.model.mesh.field.setNumbers(distance,'SurfacesList',inner);gmsh.model.mesh.field.setNumber(distance,'Sampling',100)
field=gmsh.model.mesh.field.add('Threshold')
for k,v in [('InField',distance),('SizeMin',h_inner),('SizeMax',h_outer),('DistMin',.015),('DistMax',.07)]:gmsh.model.mesh.field.setNumber(field,k,v)
gmsh.model.mesh.field.setAsBackgroundMesh(field)
gmsh.option.setNumber('Mesh.MeshSizeMin',h_inner);gmsh.option.setNumber('Mesh.MeshSizeMax',h_outer)
gmsh.option.setNumber('Mesh.MshFileVersion',2.2);gmsh.model.mesh.generate(2);gmsh.write(str(out/'surface.msh'));gmsh.finalize()
mesh=meshio.read(out/'surface.msh');tri=mesh.cells_dict['triangle'];xyz=mesh.points[tri];cross=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]);tags=mesh.cell_data_dict['gmsh:physical']['triangle'];src=tags==2
edges=np.sort(np.vstack([tri[:,[0,1]],tri[:,[1,2]],tri[:,[2,0]]]),axis=1)
assert np.all(np.unique(edges,axis=0,return_counts=True)[1]==2)
assert np.max(np.abs(np.sum(cross,axis=0)))<1e-10
assert np.all(cross[src,2]>0)
volume=float(np.sum(np.einsum('ij,ij->i',xyz[:,0],cross))/6);assert volume>0
print('PILOT mesh',len(tri),'faces',len(mesh.points),'nodes; source area',np.linalg.norm(cross[src],axis=1).sum()/2,'volume',volume)
system=dict(id='horn-exterior',name='Ideal velocity horn in finite circular baffle',model_version=1,metadata={},interfaces=[],
 meshes=[dict(id='surface',name='Solid boundary',file='surface.msh',purpose='bem_surface',scale_to_m=1.,translation_m=[0,0,0])],
 regions=[dict(id='air',name='Exterior air',kind='unbounded_air',mesh_ids=['surface'],density_kg_per_m3=1.225,sound_speed_m_per_s=343.)],
 boundaries=[dict(id=name,name=name,region_id='air',kind=kind,group=dict(mesh_id='surface',dimension=2,name=name,tag=tag)) for name,kind,tag in [('source','moving',2),('rigid','rigid',4)]],
 components=[dict(id='source-component',name='Uniform normal RMS velocity',kind='ideal_velocity_source',boundary_ids=['source'],parameters=dict(motion_profile='uniform',boundary_motion_weights={'source':1.}))],
 excitation_ports=[dict(id='velocity',name='Unit inward velocity',kind='normal_velocity',component_id='source-component')])
project=dict(schema_version=9,physical_system=system,symmetry='off',stitch_exterior_meshes=False,imported_meshes=[],observation_planes=[],component_channel_by_id={'source-component':'main'},project_preferences=dict(freq_min_hz=800.,freq_max_hz=1600.,freq_count=3,polar_observation_distance_m=1.,spherical_sampling_enabled=False))
request=dict(schema_version=1,frequencies_hz=[800.,1200.,1600.],include_project_observations=False,probes=[dict(id='onaxis',name='One metre from mouth',points_m=[[0.,0.,length+1.]])],retain=['bem_boundary_traces'],solver_options=dict(quadrature_order=4,singular_order=4))
for name,value in [('project.blab.json',project),('request.json',request),('pilot-definition.json',dict(scope='Method pilot; not an accuracy or physical validation pass',length=length,baffle_radius=radius,mesh_inner=h_inner,mesh_outer=h_outer,source_area=float(np.linalg.norm(cross[src],axis=1).sum()/2),faces=len(tri)))]:
 (out/name).write_text(json.dumps(value,indent=2)+'\n')
