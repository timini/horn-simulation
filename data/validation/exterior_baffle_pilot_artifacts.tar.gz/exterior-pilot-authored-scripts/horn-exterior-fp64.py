import sys,json
from pathlib import Path
sys.path.insert(0,'/tmp/horn-boundary-lab-pinned/src')
from blab.headless import load_headless_project,load_headless_solve_spec,prepare_headless_solve,HeadlessResultWriter
from blab.system_solve import canonicalize_observation_result
from blab.solvers.coupled_backend import CoupledReferenceBackend
out=Path(sys.argv[1]);order=int(sys.argv[2])
request=json.loads((out/'request.json').read_text())
request['solver_options'].update(regular_quadrature_mode='fixed',quadrature_order=order,singular_order=order)
path=out/f'request-fp64-q{order}.json';path.write_text(json.dumps(request,indent=2))
project=load_headless_project(out/'project.blab.json')
prepared=prepare_headless_solve(project,load_headless_solve_spec(path),backend_id='beat_cpu')
writer=HeadlessResultWriter(out/f'fp64-q{order}',project=project,prepared=prepared,backend_id='coupled_reference',public_request=request)
backend=CoupledReferenceBackend(julia_executable='/Users/timrichardson/Documents/Codex/2026-09-06/i/work/julia-runtime/julia-1.12.6/bin/julia',julia_threads=1,persistent_worker=False)
session=backend.create_system_session(prepared.request)
try:
 for raw in session.solve_stream():
  result=canonicalize_observation_result(prepared,raw)
  writer.write_result(result)
  print('Completed',result.freq_hz,dict(result.diagnostics),flush=True)
 writer.finish(status='complete')
except BaseException as exc:
 writer.finish(status='failed',error=str(exc));raise
finally:session.stop()
