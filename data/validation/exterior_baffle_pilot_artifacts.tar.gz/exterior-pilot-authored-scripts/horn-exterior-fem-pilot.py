from pathlib import Path
from horn_solver.solver import create_mesh_from_step,run_simulation
root=Path('/workspace/results/exterior-pilot-v3')
domain,facets=create_mesh_from_step(str(root/'horn-air.step'),.004,.11790625)
for frequency in (800.,1200.,1600.):
 run_simulation(domain,facets,(frequency,frequency*1.000001),2,{'length':.11790625},str(root/f'production-{frequency:g}.csv'),bc_mode='velocity',inlet_velocity_rms=1.,element_degree=1,radiation_model='flanged_piston',loss_model='lossless')
