import sys,os,importlib.util
from pathlib import Path
sys.path.insert(0,"/tmp/horn-qualify-single-horn/scripts")
spec=importlib.util.spec_from_file_location('runner','/tmp/horn-qualify-single-horn/scripts/validate_boundary_lab.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
checkout=Path('/tmp/horn-boundary-lab-pinned');assert v.reference_checkout_clean(checkout)
os.environ['JULIA_DEPOT_PATH']='/Users/timrichardson/Documents/Codex/2026-09-06/i/work/julia-depot'
os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
v.run_logged(['/Users/timrichardson/Documents/Codex/2026-09-06/i/work/boundary-lab-runtime/bin/python','-I','-B','/tmp/horn-exterior-fp64.py',sys.argv[1],sys.argv[2]],Path(sys.argv[1])/f'fp64-q{sys.argv[2]}.log',timeout=600)
assert v.reference_checkout_clean(checkout)
