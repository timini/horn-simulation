from pathlib import Path
import subprocess,json,hashlib,uuid
root=Path('/tmp/horn-modal-search');out=root/'results/qualification/modal-search-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
out.mkdir(parents=True,exist_ok=False)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
files=sorted([p for p in (root/'packages').glob('*/src/**/*.py')]+list((root/'data/drivers-curated').rglob('*.json'))+[root/'scripts/benchmark_search.py',root/'scripts/validate_candidate_resolution.py'])
hashes={str(p.relative_to(root)):sha(p) for p in files}
image_id=json.loads(Path('/tmp/horn-modal-production/results/example-modal-800-1600-v2/manifest.json').read_text())['containers']['horn-solver']['id']
image=json.loads(subprocess.check_output(['docker','image','inspect',image_id]))[0];assert image['Id']==image_id
write(out/'execution-input.json',dict(source_revision=commit,source_sha256=hashes,image_id=image_id))
(out/'source.tar.gz').write_bytes(subprocess.check_output(['git','archive','--format=tar.gz',commit,*hashes],cwd=root))
code='''import json,hashlib,runpy,sys
from pathlib import Path
p=json.loads(Path('/study/execution-input.json').read_text())
for name,digest in p['source_sha256'].items():assert hashlib.sha256((Path('/workspace')/name).read_bytes()).hexdigest()==digest,name
runtime=runpy.run_path('/workspace/scripts/validate_candidate_resolution.py')['runtime_identity']()
Path('/study/runtime.json').write_text(json.dumps(runtime,indent=2))
sys.argv=['benchmark_search.py','--output-dir','/study','--radiation-model','modal_baffled']
runpy.run_path('/workspace/scripts/benchmark_search.py',run_name='__main__')
'''
name='horn-modal-search-'+uuid.uuid4().hex
command=['docker','run','--rm','--name',name,'-e','OPENBLAS_NUM_THREADS=1','-e','OMP_NUM_THREADS=1','-e','PYTHONPATH=/workspace/packages/horn-core/src:/workspace/packages/horn-drivers/src:/workspace/packages/horn-geometry/src:/workspace/packages/horn-solver/src:/workspace/packages/horn-analysis/src:/usr/local/lib','-v',f'{root}:/workspace:ro','-v',f'{out}:/study','-w','/workspace',image_id,'python3','-u','-c',code]
result=None
try:
 result=subprocess.run(command,timeout=7200).returncode
 assert result==0,f'Benchmark exit {result}'
 assert {str(p.relative_to(root)):sha(p) for p in files}==hashes
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=root)
finally:
 subprocess.run(['docker','rm','-f',name],capture_output=True)
 write(out/'host-execution.json',dict(command=command,image_id=image_id,image_architecture=image['Architecture'],image_os=image['Os'],exit_code=result,files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()}))
